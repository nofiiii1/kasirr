package kasir.pkg12rpl.pertama;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {
    private static Connection conn;

    public static Connection getKoneksi() {
        try {
            if (conn == null || conn.isClosed()) {
                String url = "jdbc:postgresql://localhost:5432/dbrestoran";
                String user = "postgres";
                String password = "12345678"; // ganti sesuai password PostgreSQL kamu
                conn = DriverManager.getConnection(url, user, password);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi gagal: " + e.getMessage());
        }
        return conn;
    }
}
