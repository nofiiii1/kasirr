package kasir.pkg12rpl.pertama;

import com.sun.jdi.connect.spi.Connection;

public class DBConnection {
    public static Connection getKoneksi() {
        String url = "jdbc:postgresql://localhost:5432/dbrestoran";
        String user = "postgres";
        String pass = "12345678";
        return (Connection) DriverManager.getConnection(url, user, pass);
    }
}
